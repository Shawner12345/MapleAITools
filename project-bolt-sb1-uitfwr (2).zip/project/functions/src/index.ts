import * as functions from 'firebase-functions';
import * as admin from 'firebase-admin';

admin.initializeApp();

export const onWaitlistSignup = functions.firestore
  .document('waitlist/{docId}')
  .onCreate(async (snap, context) => {
    const data = snap.data();
    const email = data.email;

    try {
      await admin.firestore().collection('mail').add({
        to: email,
        message: {
          subject: 'Welcome to the Blitzen AI Waitlist!',
          html: `
            <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
              <h1 style="color: #dc2626;">Welcome to Blitzen AI!</h1>
              <p>Thank you for joining our waitlist! We're excited to have you on board.</p>
              <p>You'll be among the first to know when we launch new features for our AI-powered Christmas planning tools.</p>
              <h2 style="color: #374151;">What's Next?</h2>
              <ul>
                <li>Early access to new features</li>
                <li>Exclusive updates on our development</li>
                <li>Special launch day discounts</li>
              </ul>
              <p>Stay tuned for updates!</p>
              <p>Best regards,<br>The Blitzen AI Team</p>
            </div>
          `,
        },
      });

      // Log successful email sending
      await admin.firestore().collection('logs').add({
        type: 'waitlist_email',
        email,
        status: 'success',
        timestamp: admin.firestore.FieldValue.serverTimestamp(),
      });

    } catch (error) {
      console.error('Error sending waitlist email:', error);
      
      // Log failed email sending
      await admin.firestore().collection('logs').add({
        type: 'waitlist_email',
        email,
        status: 'error',
        error: error.message,
        timestamp: admin.firestore.FieldValue.serverTimestamp(),
      });
    }
  });