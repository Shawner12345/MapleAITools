import { useEffect } from 'react';
import { getAuth } from 'firebase/auth';

const AuthCallback = () => {
  useEffect(() => {
    const handleAuthCallback = async () => {
      const auth = getAuth();
      const next = new URLSearchParams(window.location.search).get('next') || '/';

      // If we have a user, they're already signed in through Firebase's popup
      if (auth.currentUser) {
        window.location.replace(next);
      }
    };

    handleAuthCallback();
  }, []);

  return (
    <div className="min-h-screen flex items-center justify-center">
      <div className="text-center">
        <h2 className="text-2xl font-bold text-gray-800 mb-2">Completing Sign In</h2>
        <p className="text-gray-600">Please wait while we complete your authentication...</p>
      </div>
    </div>
  );
};

export default AuthCallback;