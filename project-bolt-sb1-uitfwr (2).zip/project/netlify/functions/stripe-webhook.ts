import { Handler } from '@netlify/functions';
import Stripe from 'stripe';
import { initializeApp, getApps, cert } from 'firebase-admin/app';
import { getFirestore } from 'firebase-admin/firestore';

// Initialize Firebase Admin if not already initialized
if (!getApps().length) {
  console.log('Initializing Firebase Admin...');
  try {
    initializeApp({
      credential: cert({
        projectId: process.env.FIREBASE_PROJECT_ID,
        clientEmail: process.env.FIREBASE_CLIENT_EMAIL,
        privateKey: process.env.FIREBASE_PRIVATE_KEY?.replace(/\\n/g, '\n')
      })
    });
    console.log('Firebase Admin initialized successfully');
  } catch (error) {
    console.error('Firebase Admin initialization error:', error);
    throw error;
  }
}

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!, {
  apiVersion: '2023-10-16'
});
const db = getFirestore();

export const handler: Handler = async (event) => {
  const endpointSecret = process.env.STRIPE_WEBHOOK_SECRET;
  const payload = event.body;
  const sig = event.headers['stripe-signature'];

  console.log('Webhook received:', {
    method: event.httpMethod,
    hasSignature: !!sig,
    hasSecret: !!endpointSecret,
    payloadLength: payload?.length,
    headers: event.headers
  });

  try {
    if (event.httpMethod !== 'POST') {
      return { statusCode: 405, body: 'Method not allowed' };
    }

    if (!sig || !endpointSecret) {
      console.error('Missing stripe signature or webhook secret');
      return { 
        statusCode: 400, 
        body: JSON.stringify({ 
          error: 'Missing signature or webhook secret',
          hasSignature: !!sig,
          hasSecret: !!endpointSecret
        })
      };
    }

    // Verify webhook signature and construct event
    let stripeEvent: Stripe.Event;
    try {
      stripeEvent = stripe.webhooks.constructEvent(payload!, sig, endpointSecret);
      console.log('Webhook verified, event type:', stripeEvent.type);
    } catch (err) {
      console.error('Webhook signature verification failed:', err);
      return { 
        statusCode: 400, 
        body: JSON.stringify({ 
          error: 'Webhook signature verification failed',
          details: err instanceof Error ? err.message : 'Unknown error'
        })
      };
    }

    // Handle the event
    if (stripeEvent.type === 'checkout.session.completed') {
      const session = stripeEvent.data.object as Stripe.Checkout.Session;
      
      console.log('Processing checkout session:', {
        id: session.id,
        customer: session.customer,
        customerEmail: session.customer_details?.email,
        metadata: session.metadata,
        clientReferenceId: session.client_reference_id
      });

      const customerEmail = session.customer_details?.email;
      const userId = session.metadata?.userId || session.client_reference_id;

      if (!customerEmail || !userId) {
        console.error('Missing required data:', { customerEmail, userId });
        return { 
          statusCode: 400, 
          body: JSON.stringify({ 
            error: 'Missing required session data',
            customerEmail: !!customerEmail,
            userId: !!userId
          })
        };
      }

      try {
        // Update user plan in Firestore
        const userPlanRef = db.collection('user_plans').doc(userId);
        
        const planData = {
          hasPaid: true,
          updatedAt: new Date().toISOString(),
          stripeCustomerId: session.customer,
          email: customerEmail,
          purchaseDate: new Date().toISOString()
        };

        console.log('Updating user plan:', { userId, ...planData });
        
        await userPlanRef.set(planData, { merge: true });

        console.log('Successfully updated user plan for:', userId);

        // Log the payment
        const paymentLog = {
          userId,
          email: customerEmail,
          stripeSessionId: session.id,
          amount: session.amount_total,
          currency: session.currency,
          status: 'completed',
          timestamp: new Date().toISOString()
        };

        console.log('Logging payment:', paymentLog);
        
        await db.collection('payment_logs').add(paymentLog);

        console.log('Payment logged successfully');

        return {
          statusCode: 200,
          body: JSON.stringify({ 
            received: true,
            userId,
            status: 'success'
          })
        };
      } catch (error) {
        console.error('Error updating user data:', error);
        return { 
          statusCode: 500, 
          body: JSON.stringify({ 
            error: 'Failed to update user data',
            details: error instanceof Error ? error.message : 'Unknown error'
          })
        };
      }
    }

    return {
      statusCode: 200,
      body: JSON.stringify({ received: true })
    };
  } catch (err) {
    console.error('Webhook error:', err);
    return {
      statusCode: 500,
      body: JSON.stringify({ 
        error: err instanceof Error ? err.message : 'Internal server error',
        stack: err instanceof Error ? err.stack : undefined
      })
    };
  }
};