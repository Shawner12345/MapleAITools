import { Handler } from '@netlify/functions';
import Stripe from 'stripe';
import { initializeApp, getApps, cert } from 'firebase-admin/app';
import { getFirestore } from 'firebase-admin/firestore';

// Initialize Firebase Admin if not already initialized
if (!getApps().length) {
  initializeApp({
    credential: cert({
      projectId: process.env.FIREBASE_PROJECT_ID,
      clientEmail: process.env.FIREBASE_CLIENT_EMAIL,
      privateKey: process.env.FIREBASE_PRIVATE_KEY?.replace(/\\n/g, '\n')
    })
  });
}

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!, {
  apiVersion: '2023-10-16',
});

const db = getFirestore();

export const handler: Handler = async (event) => {
  try {
    if (event.httpMethod !== 'POST') {
      return {
        statusCode: 405,
        body: JSON.stringify({ message: 'Method not allowed' })
      };
    }

    const { sessionId } = JSON.parse(event.body || '{}');

    if (!sessionId) {
      return {
        statusCode: 400,
        body: JSON.stringify({ message: 'Session ID is required' })
      };
    }

    // Retrieve the checkout session
    const session = await stripe.checkout.sessions.retrieve(sessionId);

    // Verify payment status
    const verified = session.payment_status === 'paid';

    if (verified) {
      // Get user ID from metadata or client reference
      const userId = session.metadata?.userId || session.client_reference_id;
      const customerEmail = session.customer_details?.email;

      if (userId) {
        // Update user plan in Firestore
        const userPlanRef = db.collection('user_plans').doc(userId);
        
        await userPlanRef.set({
          hasPaid: true,
          updatedAt: new Date().toISOString(),
          stripeCustomerId: session.customer,
          email: customerEmail,
          purchaseDate: new Date().toISOString()
        }, { merge: true });

        // Log the payment
        await db.collection('payment_logs').add({
          userId,
          email: customerEmail,
          stripeSessionId: session.id,
          amount: session.amount_total,
          currency: session.currency,
          status: 'completed',
          timestamp: new Date().toISOString()
        });
      }
    }

    return {
      statusCode: 200,
      body: JSON.stringify({
        verified,
        customerId: session.customer,
        paymentStatus: session.payment_status,
        metadata: session.metadata
      })
    };
  } catch (err) {
    console.error('Payment verification error:', err);
    return {
      statusCode: 500,
      body: JSON.stringify({
        message: err instanceof Error ? err.message : 'Internal server error'
      })
    };
  }
};