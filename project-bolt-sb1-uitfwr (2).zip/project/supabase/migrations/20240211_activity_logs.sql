-- Create activity_logs table
create table public.activity_logs (
  id uuid default gen_random_uuid() primary key,
  user_id uuid references auth.users(id) on delete cascade not null,
  activity_type text not null check (activity_type in ('gift', 'meal', 'decoration', 'movie', 'date', 'elf', 'poem', 'budget')),
  content jsonb not null default '{}'::jsonb,
  created_at timestamptz default now() not null
);

-- Enable RLS
alter table public.activity_logs enable row level security;

-- Create policies
create policy "Users can insert their own activities"
  on public.activity_logs for insert
  with check (auth.uid() = user_id);

create policy "Users can view their own activities"
  on public.activity_logs for select
  using (auth.uid() = user_id);

-- Create indexes
create index activity_logs_user_id_idx on public.activity_logs(user_id);
create index activity_logs_activity_type_idx on public.activity_logs(activity_type);
create index activity_logs_created_at_idx on public.activity_logs(created_at desc);

-- Grant access to authenticated users
grant usage on schema public to authenticated;
grant all on public.activity_logs to authenticated;